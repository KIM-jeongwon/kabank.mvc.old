package com.kabank.mvc.dao;

public interface CommonDAO{
	
	public String selectTableCount();
	
}
//은닉화,상속,추상,다형성(overriding,overload)
