package com.kabank.mvc.kabankBean;

public class LottoBean {
	private String lottoNum;

	
	public void setLottoNum(String lottoNum) {
		this.lottoNum = lottoNum;
	}
	public String getLottoNum() {
		return lottoNum;
	}
}
