package com.kabank.mvc.kabankBean;

public class AccountBean {
private String accountNum,money;

public String getAccountNum() {
	return accountNum;
}

public void setAccountNum(String accountNum) {
	this.accountNum = accountNum;
}

public String getMoney() {
	return money;
}

public void setMoney(String money) {
	this.money = money;
}
}
