package com.kabank.mvc.service;

import com.kabank.mvc.kabankBean.MemberBean;

public interface MemberService {

	public boolean login(MemberBean m);

}
