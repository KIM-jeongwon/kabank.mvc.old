package com.kabank.mvc.service;

public interface BankService {

}
