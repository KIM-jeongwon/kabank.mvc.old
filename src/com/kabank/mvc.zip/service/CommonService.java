package com.kabank.mvc.service;

public interface CommonService {
	public String countTable();
	
}
