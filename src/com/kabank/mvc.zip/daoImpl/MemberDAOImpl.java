package com.kabank.mvc.daoImpl;

import com.kabank.mvc.constant.MemberSQL;
import com.kabank.mvc.dao.MemberDAO;
import com.kabank.mvc.kabankBean.MemberBean;
import com.kabank.mvc.service.MemberService;
import com.kabank.mvc.serviceImpl.MemberServiceImpl;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MemberDAOImpl implements MemberDAO{
		
	@Override
	public List<MemberBean> selectMembers() {
		String sql = "";
		List<MemberBean> list = new ArrayList<>();
		MemberBean m;
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection conn =DriverManager.getConnection(
				"jdbc:oracle:thin:@localhost:1521:xe"
				, "bitcamp", "bitcamp");
		Statement stmt = conn.createStatement();
		sql = MemberSQL.MEMBERS;
		ResultSet rs = stmt.executeQuery(sql);
		while(rs.next()) {
			m = new MemberBean();
			m.setId(rs.getString("id"));
			m.setPass(rs.getString("pass"));
			list.add(m);
		}
		System.out.println(list);
		}catch(Exception e){
			
			e.printStackTrace();
		
		}
				return list;
	}
}
