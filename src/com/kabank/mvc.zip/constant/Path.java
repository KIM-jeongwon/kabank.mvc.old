package com.kabank.mvc.constant;

public class Path {
		public static final String VIEW= "/WEB-INF/view/",
										SEPARATOR= "/",
										EXTENSION= ".jsp",
										DOT = "\\.";

}
