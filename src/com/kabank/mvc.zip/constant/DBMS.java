package com.kabank.mvc.constant;

public class DBMS {
	public static final String
	ORACLE_DRIVER ="/WEB-INF/view/",
	ORACLE_CONNECTION_URL = "/",
	ORACLE_USERNAME = ".jsp",
	ORACLE_PASSWORD = "\\.";
}
